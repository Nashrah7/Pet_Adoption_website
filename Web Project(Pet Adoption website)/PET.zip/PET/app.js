// app.js
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');
const app = express();
const port = 3000;

app.use(express.static('public')); // Assuming CSS file is in a 'public' folder

// Database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'QWer12@*',
  database: 'pet'
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));

// Set the view engine to EJS and views directory path
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Routes
app.get('/', (req, res) => {
  res.render('home');
});

app.get('/login', (req, res) => {
    res.render('login'); // This assumes you have a login.ejs file in the 'views' folder
});

// Middleware for parsing JSON in POST requests
app.use(express.json());

// Sign up route
app.post('/signup', (req, res) => {
    const { username, password } = req.body;

    // Check if the username is already taken
    const checkUsernameQuery = 'SELECT * FROM users WHERE username = ?';
    db.query(checkUsernameQuery, [username], (checkUsernameErr, checkUsernameResult) => {
        if (checkUsernameErr) {
            console.error(checkUsernameErr);
            return res.status(500).send('Error during signup');
        }

        // If the username is already taken, return an error
        if (checkUsernameResult.length > 0) {
            return res.status(400).send('Username is already taken');
        }

        // If the username is not taken, proceed with the signup
        const insertUserQuery = 'INSERT INTO users (username, password) VALUES (?, ?)';
        db.query(insertUserQuery, [username, password], (insertErr) => {
            if (insertErr) {
                console.error(insertErr);
                return res.status(500).send('Error during signup');
            }

            res.status(200).send('Registration successful'); // Adjust this response as needed
        });
    });
});

app.post('/signin', (req, res) => {
    const { username, password } = req.body;
    const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
    db.query(sql, [username, password], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Error during signin');
        }
        if (result.length > 0) {
            res.status(200).send('Login successful'); // Adjust this response as needed
        } else {
            res.status(401).send('Incorrect username or password');
        }
    });
});

app.get('/index', (req, res) => {
    // Your logic to render or send data to index.ejs
    res.render('index'); // Assuming you have an index.ejs file in the 'views' folder
});


app.post('/addUser', (req, res) => {
  const { name, age, gender, birthday, description } = req.body;
  const sql = 'INSERT INTO records (name, age, gender, birthday, description) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [name, age, gender, birthday, description], (err) => {
    if (err) throw err;
    res.redirect('/getUsers');
  });
});

app.get('/getUsers', (req, res) => {
  const sql = 'SELECT * FROM records';
  db.query(sql, (err, result) => {
    if (err) throw err;
    res.render('users', { users: result });
  });
});

app.get('/editUser/:id', (req, res) => {
  const userId = req.params.id;
  const sql = 'SELECT * FROM records WHERE id = ?';
  db.query(sql, [userId], (err, result) => {
    if (err) throw err;
    res.render('editUser', { user: result[0] });
  });
});

app.post('/updateUser/:id', (req, res) => {
  const userId = req.params.id;
  const { name, age, gender, birthday, description } = req.body;
  const sql = 'UPDATE records SET name = ?, age = ?, gender = ?, birthday = ?, description = ? WHERE id = ?';
  db.query(sql, [name, age, gender, birthday, description, userId], (err) => {
    if (err) throw err;
    res.redirect('/getUsers');
  });
});

app.get('/deleteUser/:id', (req, res) => {
  const userId = req.params.id;
  const sql = 'DELETE FROM records WHERE id = ?';
  db.query(sql, [userId], (err) => {
    if (err) throw err;
    res.redirect('/getUsers');
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
