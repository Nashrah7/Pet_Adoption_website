// public/js/login.js

function swap(formType) {
    const loginForm = document.getElementById('login');
    const signupForm = document.getElementById('signup');

    if (formType === 'signin') {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
    } else if (formType === 'signup') {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
    }
}

function signin() {
    const username = document.getElementById('user').value;
    const password = document.getElementById('password').value;

    // Send a POST request to the server for authentication
    fetch('/signin', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
    })
    .then(response => {
        if (response.ok) {
            window.location.href = '/index'; // Redirect to the getUsers page on successful login
        } else {
            throw new Error('Incorrect username or password');
        }
    })
    .catch(error => {
        document.querySelector('.error').innerText = error.message;
    });
}

function signup() {
    const username = document.getElementById('reguser').value;
    const password = document.getElementById('regpassword').value;

    // Send a POST request to the server for user registration
    fetch('/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
    })
    .then(response => {
        if (response.ok) {
            // Display a success message or redirect to a login page
            document.querySelector('.message').innerText = 'Registration successful! Please sign in.';
        } else {
            throw new Error('Error during signup');
        }
    })
    .catch(error => {
        document.querySelector('.error').innerText = error.message;
    });
}
