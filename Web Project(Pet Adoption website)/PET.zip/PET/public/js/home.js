$(document).ready(function () {
  // document.getElementsByClassName("hero-slider");
  $('.carousel-slider').cycle('scrollHorz');
});

