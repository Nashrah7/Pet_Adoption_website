// script.js
function signup() {
    const signupForm = document.getElementById('signupForm');
    const username = signupForm.signupUsername.value;
    const password = signupForm.signupPassword.value;

    // Send data to your backend for signup processing
    console.log('Signing up:', username, password);

    // Add your backend API call here

    // You may redirect the user to the dashboard or perform other actions based on the response
}

function signin() {
    const loginForm = document.getElementById('loginForm');
    const username = loginForm.loginUsername.value;
    const password = loginForm.loginPassword.value;

    // Send data to your backend for signin processing
    console.log('Signing in:', username, password);

    // Add your backend API call here

    // You may redirect the user to the dashboard or perform other actions based on the response
}
